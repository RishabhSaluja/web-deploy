<?php
/**
 * The footer without any visible content.
 */
?>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Modals -->
	<?php template_part($theme->content_sub_path.'/modals'); ?>
	<!-- /Modals -->
	
	<?php wp_footer(); ?>
</body>
</html>

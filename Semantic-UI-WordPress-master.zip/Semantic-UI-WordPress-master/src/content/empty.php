<?php
/**
 * This "empty" file is very important because it allows you to dynamically
 * exclude any part of the theme that is included via the template_part() or
 * theme::part() functions (given the part has not already been sent to PHP's
 * buffer). The idea is to reuse or change parts instead of just deleting them.
 */

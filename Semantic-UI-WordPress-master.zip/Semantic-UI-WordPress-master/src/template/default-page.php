<?php
/**
 * The default page template
 * 
 * Shows pages as the default template without any sidebars.
 */

template_part($theme->template_sub_path.'/default', 'sidebar-none');

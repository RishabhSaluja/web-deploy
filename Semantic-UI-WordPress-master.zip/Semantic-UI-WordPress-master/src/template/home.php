<?php
/*
Template Name: Home With Posts
*/

// This just an alias to the default
template_part($theme->template_sub_path.'/default');

module.exports = function() {
	// Setup Vars
	var cli = require('../cli');
	
	cli.run('phpunit');
};
